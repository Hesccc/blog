// 加载导航栏
$(function (){
    $(".nav").load("nav.html");
});